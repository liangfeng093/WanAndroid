package com.liangfeng.wanandroid.features.home

import android.widget.ImageView
import com.liangfeng.wanandroid.ImageLoader

/**
 * Created by mzf on 2018/9/28.
 * Email:liangfeng093@gmail.com
 * Desc:
 */
open class ImgLoader:ImageLoader {
    override fun loadImg(imgView: ImageView, picPath: String) {

    }
}