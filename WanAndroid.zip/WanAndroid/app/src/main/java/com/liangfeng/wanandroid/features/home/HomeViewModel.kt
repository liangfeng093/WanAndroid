package com.liangfeng.wanandroid.features.home

import android.arch.lifecycle.ViewModel

/**
 * Created by mzf on 2018/9/28.
 * Email:liangfeng093@gmail.com
 * Desc:
 */
class HomeViewModel : ViewModel() {

}