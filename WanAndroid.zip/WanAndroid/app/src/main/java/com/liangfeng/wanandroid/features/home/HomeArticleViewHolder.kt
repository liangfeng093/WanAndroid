package com.liangfeng.wanandroid.features.home

import android.content.Context
import android.view.View
import com.liangfeng.wanandroid.base.BaseViewHolder

/**
 * Created by mzf on 2018/9/28.
 * Email:liangfeng093@gmail.com
 * Desc:
 */
class HomeArticleViewHolder: BaseViewHolder<ImgLoader> {

    constructor(itemView: View?, context: Context?) : super(itemView, context){

    }
}